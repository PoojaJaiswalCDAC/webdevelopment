import React, { Component } from 'react'  
import { Polar } from 'react-chartjs-2';  
import axios from 'axios';  
import Temp from '../Temp/Temp';
  
export class Polararea extends Component {  
        constructor(props) {  
                super(props);  
                this.state = { Data: {} };  
        }  
        componentDidMount() {  
                axios.get(`https://api.weatherbit.io/v2.0/forecast`)  
                        .then(res => {  
                                console.log(res);  
                                const weather = res.data;  
                                let Days = [];  
                                let Temp = [];  
                                ipl.forEach(record => {  
                                        Days.push(record.Days);  
                                        Temp.push(record.Temp);  
                                });  
                                this.setState({  
                                        Data: {  
                                                labels: Days,  
                                                datasets: [  
                                                        {  
                                                                label:' data shows',  
                                                                data: Temp,  
                                                                backgroundColor: [  
                                                                        "#3cb371",  
                                                                        "#0000FF",  
                                                                        "#9966FF",  
                                                                        "#4C4CFF",  
                                                                        "#00FFFF",  
                                                                        "#f990a7",  
                                                                        "#aad2ed",  
                                                                        "#FF00FF",  
                                                                        "Blue",  
                                                                        "Red"  
                                                                ]  
                                                        }  
                                                ]  
                                        }  
                                });  
                        })  
        }  
        render() {  
                return (  
                        <div>  
                      <Polar data={this.state.Data}  
                   options={{ maintainAspectRatio: false }} />  
                        </div>  
                )  
        }  
}  
  
export default Polararea  ;