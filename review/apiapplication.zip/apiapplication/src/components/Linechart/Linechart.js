import React, { Component } from 'react'  
import axios from 'axios';  
import { Line } from 'react-chartjs-2';  
export class Linecharts extends Component {  
        constructor(props) {  
                super(props);  
                this.state = { Data: {} };  
        }  
        componentDidMount() {  
                axios.get(`https://api.weatherbit.io/v2.0/forecast`)  
                        .then(res => {  
                                console.log(res);  
                                const weather = res.data;  
                                let Days = [];  
                                let Temp = [];  
                                ipl.forEach(record => {  
                                        Days.push(record.Days);  
                                        Temp.push(record.Temp);  
                                });  
                                this.setState({  
                                        Data: {  
                                                labels: Days,  
                                                datasets: [  
                                                        {  
                                                                label: 'data shows',  
                                                                data: Temp,  
                                                                backgroundColor: [  
                                                                        "#3cb371",  
                                                                        "#0000FF",  
                                                                        "#9966FF",  
                                                                        "#4C4CFF",  
                                                                        "#00FFFF",  
                                                                        "#f990a7",  
                                                                        "#aad2ed",  
                                                                        "#FF00FF",  
                                                                        "Blue",  
                                                                        "Red"  
                                                                ]  
                                                        }  
                                                ]  
                                        }  
                                });  
                        })  
        }  
        render() {  
                return (  
                        <div>  
                                <Line  
                                        data={this.state.Data}  
                                        options={{ maintainAspectRatio: false }} />  
                        </div>  
                )  
        }  
}  
  
export default Linecharts  ;