import React from "react";
import "./Days.css";

const Days = props => {
  return <div className="Days">{props.day}</div>;
};

export default Days;