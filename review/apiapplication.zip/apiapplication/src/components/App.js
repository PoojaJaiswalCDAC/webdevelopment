import React from "react";
import "./App.css";
import weather from "../apis/api";

import Piechart from '../apis/api';
import Barchart from '../apis/api';
import Polararea from '../apis/api';
import Linechart from '../apis/api';
import Doughnut from '../apis/api';


 
import WeatherBody from "./WeatherBody/WeatherBody";
import Loader from "./Loader/Loader";
import SearchBar from "./SearchBar/SearchBar";

//

// import Piechart from './piechart'  
// import Doughnutchart from './Doughnutchart'  
// import Barchart from './Barchart'  
// import Linecharts from './linecharts'  
// import Polararea from './Polararea'  
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';  
//

class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      temp: [],
      city: null,
      isLoaded: false
    };
  }

  componentDidMount() {
    this.setState({ isLoaded: true });
  }

  searchCity = async city => {
    await weather
      .get(`daily?city=${city}&key=3883f69ab25f46dc92cdf2b5d66a1517`)
      .then(res => {
        const temp = res.data.data;
        const city = res.data.city_name;

        this.setState({
          temp,
          city
        });
      });
  };

  render() {
    // Methods

    const minTemp = this.state.temp.map(el => {
      return parseInt(el.low_temp);
    });

    const maxTemp = this.state.temp.map(el => {
      return parseInt(el.max_temp);
    });

    const icon = this.state.temp.map(el => {
      return el.weather.code;
    });

    const description = this.state.temp.map(el => {
      return el.weather.description;
    });

    // Loader
    if (!this.state.isLoaded) {
      return <Loader msg={"Loading..."} />;
    }
    return (

//

<div className="App">  
<Router>  
  <div> 
//

<React.Fragment>
          <SearchBar city={this.state.city} searchCity={this.searchCity} />
        </React.Fragment>
        <div className="weatherContainer pt-3 pb-3">
          <h5 className="cityName">{this.state.city}</h5>
          <WeatherBody day={"Friday"}  icon={icon[0]} minTemp={minTemp[0]} maxTemp={maxTemp[0]} description={description[0]} />
          <WeatherBody day={"Saturday"}   icon={icon[1]} minTemp={minTemp[1]} maxTemp={maxTemp[1]} description={description[1]} />
          <WeatherBody day={"Sunday"}   icon={icon[2]} minTemp={minTemp[2]} maxTemp={maxTemp[2]} description={description[2]} />
          <WeatherBody day={"Monday"}   icon={icon[3]} minTemp={minTemp[3]} maxTemp={maxTemp[3]} description={description[3]} />
          <WeatherBody day={"Tuesday"}   icon={icon[4]} minTemp={minTemp[4]} maxTemp={maxTemp[4]} description={description[4]} />
        </div>

//
    <div class="row" className="hdr">  
      <div class="col-sm-12 btn btn-warning">  
        Charts in ReactJS  
    </div>  
    </div>  
    <div class="row" style={{ marginTop: "10px" }}> 
     <div class="col-sm-1">  
      </div>  
      <div class="col-sm-2">  
        <Link to={'/Piechart'} className="nav-link btn btn-info">Piechart</Link>  
      </div>  
      <div class="col-sm-2">  
        <Link to={'/Barchart'} className="nav-link btn btn-info">Bar Chart</Link>  
      </div>  
      <div class="col-sm-2">  
        <Link to={'/Linechart'} className="nav-link btn btn-info">Line Chart</Link>  
      </div>  
      <div class="col-sm-2">  
        <Link to={'/Doughnut'} className="nav-link btn btn-info">Doughnut Chart</Link>  
      </div>  
      <div class="col-sm-2">  
        <Link to={'/Polararea'} className="nav-link btn btn-info">Polar Chart</Link>  
      </div>  
      <div class="col-sm-1">  
      </div>  
    </div>  
  </div>  
  <div className="container">  
    <Switch>  
      <Route exact path='/Piechart' component={Piechart} />  
      <Route path='/Barchart' component={Barchart} />  
      <Route path='/Polararea' component={Polararea} />  
      <Route path='/Doughnut' component={Doughnut} />  
      <Route path='/Linechart' component={Linechart} />  
    </Switch>  
  </div>  
</Router>  
</div>  
    );
    // return(

    // <div className="App">
    //     <React.Fragment>
    //       <SearchBar city={this.state.city} searchCity={this.searchCity} />
    //     </React.Fragment>
    //     <div className="weatherContainer pt-3 pb-3">
    //       <h5 className="cityName">{this.state.city}</h5>
    //       <WeatherBody day={"Friday"}  icon={icon[0]} minTemp={minTemp[0]} maxTemp={maxTemp[0]} description={description[0]} />
    //       <WeatherBody day={"Saturday"}   icon={icon[1]} minTemp={minTemp[1]} maxTemp={maxTemp[1]} description={description[1]} />
    //       <WeatherBody day={"Sunday"}   icon={icon[2]} minTemp={minTemp[2]} maxTemp={maxTemp[2]} description={description[2]} />
    //       <WeatherBody day={"Monday"}   icon={icon[3]} minTemp={minTemp[3]} maxTemp={maxTemp[3]} description={description[3]} />
    //       <WeatherBody day={"Tuesday"}   icon={icon[4]} minTemp={minTemp[4]} maxTemp={maxTemp[4]} description={description[4]} />
    //     </div>
    //   </div>
    // );
  }
}
  






//
// function App() {  
//   return (  
//     <div className="App">  
//       <Router>  
//         <div>  
//           <div class="row" className="hdr">  
//             <div class="col-sm-12 btn btn-warning">  
//               Charts in ReactJS  
//           </div>  
//           </div>  
//           <div class="row" style={{ marginTop: "10px" }}> >  
//            <div class="col-sm-1">  
//             </div>  
//             <div class="col-sm-2">  
//               <Link to={'/Piechart'} className="nav-link btn btn-info">Piechart</Link>  
//             </div>  
//             <div class="col-sm-2">  
//               <Link to={'/Barchart'} className="nav-link btn btn-info">Bar Chart</Link>  
//             </div>  
//             <div class="col-sm-2">  
//               <Link to={'/Linecharts'} className="nav-link btn btn-info">Line Chart</Link>  
//             </div>  
//             <div class="col-sm-2">  
//               <Link to={'/Doughnut'} className="nav-link btn btn-info">Doughnut Chart</Link>  
//             </div>  
//             <div class="col-sm-2">  
//               <Link to={'/Polararea'} className="nav-link btn btn-info">Polar Chart</Link>  
//             </div>  
//             <div class="col-sm-1">  
//             </div>  
//           </div>  
//         </div>  
//         <div className="container">  
//           <Switch>  
//             <Route exact path='/Piechart' component={Piechart} />  
//             <Route path='/Barchart' component={Barchart} />  
//             <Route path='/Polararea' component={Polararea} />  
//             <Route path='/Doughnut' component={Doughnutchart} />  
//             <Route path='/Linecharts' component={Linecharts} />  
//           </Switch>  
//         </div>  
//       </Router>  
//     </div>  
     
    
export default App;  


//


// class App extends React.Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//       temp: [],
//       city: null,
//       isLoaded: false
//     };
//   }

//   componentDidMount() {
//     this.setState({ isLoaded: true });
//   }

//   searchCity = async city => {
//     await weather
//       .get(`daily?city=${city}&key=3883f69ab25f46dc92cdf2b5d66a1517`)
//       .then(res => {
//         const temp = res.data.data;
//         const city = res.data.city_name;

//         this.setState({
//           temp,
//           city
//         });
//       });
//   };

//   render() {
//     // Methods

//     const minTemp = this.state.temp.map(el => {
//       return parseInt(el.low_temp);
//     });

//     const maxTemp = this.state.temp.map(el => {
//       return parseInt(el.max_temp);
//     });

//     const icon = this.state.temp.map(el => {
//       return el.weather.code;
//     });

//     const description = this.state.temp.map(el => {
//       return el.weather.description;
//     });

//     // Loader
//     if (!this.state.isLoaded) {
//       return <Loader msg={"Loading..."} />;
//     }
//     return (
//       <div className="App">
//         <React.Fragment>
//           <SearchBar city={this.state.city} searchCity={this.searchCity} />
//         </React.Fragment>
//         <div className="weatherContainer pt-3 pb-3">
//           <h5 className="cityName">{this.state.city}</h5>
//           <WeatherBody day={"Friday"}  icon={icon[0]} minTemp={minTemp[0]} maxTemp={maxTemp[0]} description={description[0]} />
//           <WeatherBody day={"Saturday"}   icon={icon[1]} minTemp={minTemp[1]} maxTemp={maxTemp[1]} description={description[1]} />
//           <WeatherBody day={"Sunday"}   icon={icon[2]} minTemp={minTemp[2]} maxTemp={maxTemp[2]} description={description[2]} />
//           <WeatherBody day={"Monday"}   icon={icon[3]} minTemp={minTemp[3]} maxTemp={maxTemp[3]} description={description[3]} />
//           <WeatherBody day={"Tuesday"}   icon={icon[4]} minTemp={minTemp[4]} maxTemp={maxTemp[4]} description={description[4]} />
//         </div>
//       </div>
//     );
//   }
// }

// export default App