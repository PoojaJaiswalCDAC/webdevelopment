import React, { Component } from 'react'  
import axios from 'axios';  
import {Doughnut} from 'react-chartjs-2';  
export class Doughnutchart extends Component {  
        render() {  
                return (  
                        <div>  
                                  
                        </div>  
                )  
        }  constructor(props) {  
                super(props);  
                this.state = { Data: {} };  
        }  
        componentDidMount() {  
                axios.get(`https://api.weatherbit.io/v2.0/forecast`)  
                        .then(res => {  
                                console.log(res);  
                                const weather = res.data;  
                                let Days = [];  
                                let Temp = [];  
                                ipl.forEach(record => {  
                                        playername.push(record.Playername);  
                                        Temp.push(record.Temp);  
                                });  
                                this.setState({  
                                        Data: {  
                                                labels: Days,  
                                                datasets: [  
                                                        {  
                                                                label: 'data shows',  
                                                                data: Temp,  
                                                                backgroundColor: [  
                                                                        "#3cb371",  
                                                                        "#0000FF",  
                                                                        "#9966FF",  
                                                                        "#4C4CFF",  
                                                                        "#00FFFF",  
                                                                        "#f990a7",  
                                                                        "#aad2ed",  
                                                                        "#FF00FF",  
                                                                        "Blue",  
                                                                        "Red"  
                                                                ]  
                                                        }  
                                                ]  
                                        }  
                                });  
                        })  
        }  
        render() {  
                return (  
                        <div>  
                      <Doughnut data={this.state.Data}  
                                        options={{ maintainAspectRatio: false }} />  
                        </div>  
                )  
        }  
}  
  
export default Doughnutchart  ;